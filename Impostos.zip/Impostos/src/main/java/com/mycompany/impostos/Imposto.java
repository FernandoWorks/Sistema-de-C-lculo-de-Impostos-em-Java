

package com.mycompany.impostos;


public class Imposto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

    String getDescricao() {
        
        return null;
        
    }

    double calcular() {
        
        

   
    return 0.0; 
}
        
    }

